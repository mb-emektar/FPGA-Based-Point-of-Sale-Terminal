%read the image
I = imread('image.png');	
imshow(I);
		
%Extract RED, GREEN and BLUE components from the image
R = I(:,:,1);			
G = I(:,:,2);
B = I(:,:,3);

COLOR_R = R;
COLOR_G = G;
COLOR_B = B;

%save variable COLOR to a file in HEX format for the chip to read
fileID = fopen ('image_r.list', 'w');
for i = 1:size(COLOR_R(:), 1)-1
    fprintf (fileID, '%x\n', COLOR_R(i)); % COLOR (dec) -> print to file (hex)
end
fprintf (fileID, '%x', COLOR_R(size(COLOR_R(:), 1))); % COLOR (dec) -> print to file (hex)
%save variable COLOR to a file in HEX format for the chip to read
%fileID = fopen ('image.list', 'w');
%fprintf (fileID, '%x\n', COLOR); % COLOR (dec) -> print to file (hex)
fclose (fileID);

fileID = fopen ('image_g.list', 'w');
for i = 1:size(COLOR_G(:), 1)-1
    fprintf (fileID, '%x\n', COLOR_G(i)); % COLOR (dec) -> print to file (hex)
end
fprintf (fileID, '%x', COLOR_G(size(COLOR_G(:), 1)));
fclose (fileID);

fileID = fopen ('image_b.list', 'w');
for i = 1:size(COLOR_B(:), 1)-1
    fprintf (fileID, '%x\n', COLOR_B(i)); % COLOR (dec) -> print to file (hex)
end
fprintf (fileID, '%x', COLOR_B(size(COLOR_B(:), 1)));
fclose (fileID);

%translate to hex to see how many lines
COLOR_R_HEX = dec2hex(COLOR_R);
COLOR_G_HEX = dec2hex(COLOR_G);
COLOR_B_HEX = dec2hex(COLOR_B);
